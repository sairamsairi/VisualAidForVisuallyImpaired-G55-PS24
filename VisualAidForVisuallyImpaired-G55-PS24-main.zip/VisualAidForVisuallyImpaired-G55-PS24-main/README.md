# VisualAidForVisuallyImpaired-G55-PS24
Repo for Visual Aid for visually impaired
